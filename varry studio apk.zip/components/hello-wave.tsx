import { useEffect } from "react";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from "react-native-reanimated";

export function HelloWave() {
  const rotation = useSharedValue(0);

  useEffect(() => {
    rotation.value = withRepeat(
      withSequence(
        withTiming(-20, { duration: 120 }),
        withTiming(18, { duration: 120 }),
        withTiming(0, { duration: 120 }),
      ),
      4,
      false,
    );
  }, [rotation]);

  const waveStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }));

  return (
    <Animated.Text
      style={[
        {
          fontSize: 28,
          lineHeight: 32,
          marginTop: -6,
        },
        waveStyle,
      ]}
    >
      👋
    </Animated.Text>
  );
}
