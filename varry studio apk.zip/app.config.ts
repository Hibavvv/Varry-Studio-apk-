import { ExpoConfig, ConfigContext } from 'expo/config';

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: "varryapp",
  slug: "varryapp",
  version: "1.0.0",
  extra: {
    eas: {
      projectId: "e74dd657-d628-4844-b836-754cbae587f2"
    }
  }
});